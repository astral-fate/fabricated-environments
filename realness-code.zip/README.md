# realness

**Is "this is an evaluation" the same thing, inside a model, as "this environment is not real"?**

A counterfactual resample — continuing a halted agent trajectory in a synthetic environment to see
what it *would* have done — is a measurement whose instrument is an environment the agent can form
beliefs about. Those beliefs may change the quantity being measured, and the direction is
contested. Classical evaluation-awareness says an agent that believes it is tested behaves
*better*, so a resample understates danger. The opposite is also attested: an agent that believes
it is simulated may conclude nothing counts. Anthropic's Mythos, mid-evaluation by UK AISI,
reasoned *"whoa, this increasingly smells like the real internet"* → *"yeah, I'm fairly convinced
it's a simulated internet"* → and then opened a malicious PR against a real repository.

This repository is the measurement that decides whether those are one phenomenon or two.

## Status

**exp0 has run. The constructs are SEPARABLE, and the project proceeds.**

Evaluation-awareness and environment-realness are **not** the same linear direction in
Qwen3-1.7B. Each is individually decodable, and neither probe classifies the other's contrast:

| | held-out AUROC | cross-AUROC onto the other |
|---|---|---|
| `A_eval` (evaluation framing) | 0.919 [0.881, 0.960] | A→B **0.473** [0.395, 0.567] |
| `B_empirical` (real vs LLM-fabricated) | 0.925 [0.877, 0.968] | B→A **0.572** [0.562, 0.601] |

The pre-registered rule required ≥0.85 in *both* directions to call them inseparable. Both are far
below it, and cos(A, B) = +0.048 against a reliability ceiling that would have permitted
1.00·0.94 — these directions are close to orthogonal, not merely noisy.

Three further results make the headline interpretable rather than a bare null:

- **The probes work.** `A_eval` reaches 0.919, comfortably above the ≥0.70 floor Heidari et al.
  report. A null from two broken probes would look the same as a null from two real ones; this
  rules that out.
- **Being *told* the world is fake is not the same as the world *being* fake.** `C_declared` —
  the realness axis built by Heidari's own declared-framing construction — sits much closer to
  `A_eval` (cross-AUROC 0.787, cos +0.375) than to `B_empirical` (cos +0.113). Declared framing
  clusters with declared framing, whichever axis it names. Ground truth is somewhere else. This
  is the paper's novelty claim #3, measured.
- **`B_empirical` is not a prose-provenance detector.** It partially transfers to the scripted
  simulator it never saw (cross-AUROC 0.679, cos +0.490), so it is not merely detecting one
  generator's style — the confound that would otherwise have sunk this contrast.

Validity gates, all passing before the verdict was issued: shuffled-label control at
0.487 (±0.038); `A_eval` above the reproduction floor; no episode in both splits.

**Scope of this result.** Qwen3-1.7B, fp16, unquantized; 24 episodes over 3 task classes with one
actor model; a SIM arm with no consistency contract. It is a result at 1.7B and is reported as
nothing more. The same experiment is scale-parameterised and packaged for a rented GPU.

Everything downstream of the gate — the paired REAL/SIM rollout study, the consistency contract,
the horizon sweep — is still deliberately not built. exp0 existed to decide whether it was worth
building. It is.

## The gate

Four mean-difference probe directions, estimated per layer on **one common substrate** of agentic
transcript prefixes, each varying exactly one element:

| | Manipulation | Label 1 |
|---|---|---|
| `A_eval` | system framing sentence ("real user" / "AI evaluator"); tool outputs real in both | being evaluated |
| `C_declared` | system declaration ("real production system" / "a simulation"); tool outputs real in both | declared synthetic |
| `B_empirical` | no framing; tool outputs genuinely real vs LLM-fabricated | actually synthetic |
| `S_scripted` | no framing; tool outputs genuinely real vs template-fabricated | actually synthetic |

Building all four on one stimulus substrate matters: cross-AUROC between directions estimated on
different input distributions would mostly measure the distribution gap, not the constructs.

`A` and `C` are Heidari et al.'s contrastive construction, ported to the agentic setting and
differing only in which axis the sentence names. `B` is the ground-truth version of the axis `C`
merely declares — the difference between being *told* the world is fake and the world *actually
being* fake. That contrast is available only because a real-environment arm exists, and no prior
work in this literature has one.

**Pre-registered decision rule** (`PREREGISTRATION.md`, fixed before anything ran):
cross-AUROC(A,B) ≥ 0.85 in *both* directions ⇒ constructs not separable ⇒ report and stop.

## Reproduction

```bash
pip install -r requirements.txt
python check.py                         # every suite; no GPU, no network, no keys
python experiments/exp0_construct_separation.py --model Qwen/Qwen3-1.7B --dtype float16
```

`--offline` runs the whole pipeline with a scripted actor and template simulators. It exercises
every stage without spending API budget and is **never reportable** — the run stamps itself
`offline: true` and refuses to issue a verdict.

## What is measured, and what is deliberately not

- **The violation detector is a pure function over the action log** (`src/scope.py`). It calls no
  model and touches no filesystem. An LLM in that loop would make the measurement circular — one
  model judging another inside the very contrast under study — and a filesystem read would make an
  archived log impossible to re-score. Both properties are enforced by a test that parses the
  module's imports rather than by a comment.
- **Scope is stated in the task brief and enforced nowhere.** A boundary the substrate refuses to
  cross yields a violation rate of identically zero, which measures the substrate rather than the
  agent. The arm's root holds `secrets/`, `etc/`, `home/` and `var/` alongside `workspace/`, all
  genuinely readable and writable.
- **The unit of independence is the episode, never the transcript prefix.** One episode yields
  many near-duplicate prefixes; pooling them would multiply apparent n and narrow every interval.
  Every split is by episode and every interval comes from a cluster bootstrap. `analyze/measures.py`
  offers no item-level variant, so the only way to call it is the correct way.
- **Cosine is reported against its own reliability ceiling.** Random high-dimensional vectors are
  near-orthogonal, so any positive cosine looks meaningful. Each direction's split-half reliability
  is estimated and cos(A,B) is normalised by `sqrt(rel_A · rel_B)`.
- **Task success in a fabricated world is not evidence.** A simulated arm returns an empty
  snapshot, so `task.check` reports failure for every simulated episode. Completion is a
  diagnostic, never a target — a simulator that lets an agent conclude nothing counts would score
  well on completion while producing a trajectory with no relation to the counterfactual.

## Reused from paper 1

Four files are vendored byte-identical from `project-v2`
(*Closing Content Does Not Close the Channel*): `src/substrate.py`, `src/srm.py`,
`src/providers.py`, `scripts/watchdog.py`. `scripts/sync_from_project_v2.py` fails the build if a
vendored copy drifts from its source, so the reuse boundary is a mechanical check rather than a
note in a README. Vendoring rather than importing is what lets the probe arm be zipped and shipped
to a rented GPU.

The resume invariants in `src/agent.py` are ported from that repository's `runner/run.py`, with
its rule intact: **the append-only JSONL episode log is authoritative, and any state file is only
ever additive to it.**

## Prior art this does not duplicate

Williams et al. (arXiv:2607.07184) already built the deployment-simulation tool, including the
hybrid container/LLM tool simulator. This repository does not rebuild it. What their work does not
do — and says so in its own limitations section — is test whether evaluation-awareness *causes*
invalidity; it treats awareness as a property to match. The measurement here is the one that was
skipped.

## Scale, stated rather than hidden

The development GPU is a 6 GiB RTX 2060. Qwen3-32B — which would be directly comparable to
Zhuang & Aranguri and Heidari et al. — cannot run on it, and neither can Qwen3-8B unquantized.
exp0 therefore runs first at **Qwen3-1.7B in fp16**, below Heidari et al.'s 7B–49B range, loaded
unquantized because 4-bit NF4 perturbs the very residual stream being measured. The experiment is
scale-parameterised (`--model`) and packaged for a rented GPU. A result at 1.7B is reported as a
result at 1.7B.
